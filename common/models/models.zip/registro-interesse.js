'use strict';

module.exports = function(Registrointeresse) {

};
