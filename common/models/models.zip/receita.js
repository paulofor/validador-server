'use strict';

module.exports = function(Receita) {

};
