'use strict';

module.exports = function(Palavrachaveads) {

};
