'use strict';

module.exports = function(Container) {

};
