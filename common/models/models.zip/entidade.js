'use strict';

module.exports = function(Entidade) {

};
