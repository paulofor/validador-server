'use strict';

module.exports = function (Entidade) {


    /**
 *
 * @param {number} idEntidade
 * @param {Function(Error, array)} callback
 */

    Entidade.listaCompletaRelacionemnto = function (idEntidade, callback) {
        var listaRelacionamento;
        // TODO
        callback(null, listaRelacionamento);
    };
};
