'use strict';

module.exports = function(Projetoexemplo) {

};
