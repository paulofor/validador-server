'use strict';

module.exports = function(Relacionamentoentidade) {

};
