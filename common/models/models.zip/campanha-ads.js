'use strict';

module.exports = function(Campanhaads) {

};
