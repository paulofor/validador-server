'use strict';

module.exports = function(Projetocanvas) {

};
