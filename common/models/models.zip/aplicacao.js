'use strict';

module.exports = function(Aplicacao) {

};
