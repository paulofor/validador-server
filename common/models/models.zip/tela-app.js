'use strict';

module.exports = function(Telaapp) {

};
