'use strict';

module.exports = function(Campanhaanuncioresultado) {

};
