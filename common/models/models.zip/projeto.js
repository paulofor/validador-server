'use strict';

module.exports = function(Projeto) {

};
