'use strict';

module.exports = function(Campanhapalavrachaveresultado) {

};
