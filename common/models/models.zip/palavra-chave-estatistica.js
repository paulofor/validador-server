'use strict';

module.exports = function (Palavrachaveestatistica) {


    /**
     * Insere uma lista de itens coletados
     * @param {array} listaResultados
     * @param {Function(Error)} callback
     */

    Palavrachaveestatistica.InsereLista = function (listaResultados, callback) {
        // TODO
        callback(null);
    };

    Palavrachaveestatistica.InsereListaTeste = function (listaResultados, callback) {
        // TODO
        callback(null);
    };

};
