'use strict';

module.exports = function(Paginavalidacaoweb) {

};
