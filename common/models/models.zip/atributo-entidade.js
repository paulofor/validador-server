'use strict';

module.exports = function(Atributoentidade) {

};
