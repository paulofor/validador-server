'use strict';

module.exports = function(Grupopalavrachave) {

};
