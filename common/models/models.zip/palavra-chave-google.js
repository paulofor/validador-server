'use strict';

module.exports = function(Palavrachavegoogle) {

};
