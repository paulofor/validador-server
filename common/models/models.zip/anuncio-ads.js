'use strict';

module.exports = function(Anuncioads) {


 /**
 * 
 * @param {number} idPagina 
 * @param {Function(Error, array)} callback
 */

Anuncioads.paraCampanhaPorIdPagina = function(idPagina, callback) {
    var listaAnuncioAds;
    // TODO
    callback(null, listaAnuncioAds);
  };
};
