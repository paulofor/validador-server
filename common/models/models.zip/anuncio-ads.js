'use strict';

module.exports = function(Anuncioads) {

};
