'use strict';

module.exports = function(Modelocampanhaads) {

};
