'use strict';

module.exports = function(Projetomysql) {

};
