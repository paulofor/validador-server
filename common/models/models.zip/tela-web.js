'use strict';

module.exports = function(Telaweb) {

};
