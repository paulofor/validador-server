'use strict';

module.exports = function(Ganhodorcanvasmysql) {

};
